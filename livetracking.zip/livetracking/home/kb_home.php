<?php
	session_start();
    //$_SESSION["uname"] = "test1";

	//$_SESSION[login0] = $_POST[login];
	//echo $_SESSION[login0]."<br>";
	
	//$_SESSION[password0] = $_POST[password];
	
	//echo $_SESSION[nama0]."<br>";


$timezone = "Asia/Jakarta";
if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
//echo date('d-m-Y H:i:s');
?>


<body bgcolor="#808000">

	<?php
	
	print "<b>". "Medan, " .date("Y-m-d")."</b>"."<br>"."<br>"; 

	//if($c_profile0==null)   
	if(isset($_SESSION['c_profile0']) && !empty($_SESSION['c_profile0'])) {
   		echo "<br>"."Welcome: ".$_SESSION['nama0']."<BR>";
	}
	else{

	}
	
	// if($_SESSION['c_profile0']==null)   
	// {
	// //include "login.html";
	// //print "<br>";
	// }
	// else
	// {
	// //print "c_profile0 = ".$_SESSION[c_profile0]."<br>";
	// print "<br>"."Welcome: ".$_SESSION['nama0']."<BR>";
	// //PRINT "<a href=logout.php>Logout</a>";
	// }
	?> 

</body>



<table>

<tr>
<div>	 
<a href="kb_home.php"><img src="../images/home.jpg" alt="" width="160" height="22" border="0"></a>
</div>
</tr>		 



<tr>
<div>	 
<a href="../login/login.php" target="tengah_bawah"><img src="../images/login.jpg" alt="" width="160" height="22" border="0"></a>
</div>
</tr>		 

<tr>
<div>	 
<a href="../login/logout.php" target="tengah_bawah"> <img src="../images/logout.jpg" alt="" width="160" height="22" border="0"></a>
</div>
</tr>	


<tr>
<div> 
<a href="../login/password_change.php" target="tengah_bawah"><img src="../images/changepassword.jpg" alt="" width="160" height="22" border="0"></a>
</div>
</tr>	 

<tr>
<div>	 
<a href="../admin/admin.php" target="tengah_bawah"><img src="../images/administrator.jpg" alt="" width="160" height="22" border="0"></a>
</div>
</tr>	 


<tr>
<div>	 
<a href="who_am_i.php" target="tengah_bawah"><img src="../images/whoami.jpg" alt="" width="160" height="22" border="0"></a>
</div>
</tr>	 


</table>


<br>
<br>

<tr>
<div>	 
<a href="../admin/alpro/alpro_rekap.php" target="tengah_bawah">Route Alpro</a>
</div>
</tr>	


<tr>
<div>	 
<a href="../admin/alpro/gangguan_list.php" target="tengah_bawah">Gangguan List</a>
</div>
</tr>	

