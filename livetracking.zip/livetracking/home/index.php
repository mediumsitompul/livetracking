<!-- frames -->
<frameset  rows="17%,*" cols="15%,*">
    <frame name="kiri_atas" src="home/kiri_atas.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frame name="kanan_atas" src="home/kanan_atas.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frame name="kiri_bawah" src="home/kiri_bawah.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frame name="kanan_bawah" src="home/kanan_bawah.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
</frameset>
