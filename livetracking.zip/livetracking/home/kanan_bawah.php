



<BODY BGCOLOR=teal>
<table align="left">
   <FORM NAME="identity" METHOD="post" ACTION="hotnews_add_process.php">
	
	
	Subject	: <INPUT TYPE="text" NAME="subject" size="24"><br>
	News    : 
	<TEXTAREA NAME="news" ROWS=5 COLS=20>
	</TEXTAREA>
	<INPUT TYPE="button" VALUE="Submit" onClick=pesan()>
	
	
   </FORM>
   
</BODY>
</HTML>
