<body bgcolor=silver>

    <?php
	//include "application.php";
	
	print $_REQUEST["PHPSESSID"];
	?>

 
</body>

