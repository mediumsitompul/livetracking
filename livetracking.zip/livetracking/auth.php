<?php	
	if(isset($_SESSION['login0']) && !empty($_SESSION['login0']))
		echo "login0=". $_SESSION["login0"]. "<br>";
		
	if(isset($_SESSION['password0']) && !empty($_SESSION['password0']))
		echo "password0=".$_SESSION['password0']."<br>";
	    
	if(isset($_SESSION['nama0']) && !empty($_SESSION['nama0']))
		echo "nama0=". $_SESSION['nama0']. "<br>";
		
	if(isset($_SESSION['c_profile0']) && !empty($_SESSION['c_profile0']))
		echo "c_profile0=".$_SESSION['c_profile0']."<br>";
?>



<?php
	$script_name=trim($_SERVER['SCRIPT_NAME']);		//OK	
	echo "script_name=".$_SERVER['SCRIPT_NAME']."<br>"; //OKE ****************************************************  OKE OKE *****************************************************************
 ?>
 


<?php
	if(isset($_SESSION['c_profile0']) && !empty($_SESSION['c_profile0']))
	{
	$c_profile0=$_SESSION['c_profile0'];
	}
	else
	{
	$c_profile0='';
	}
 ?>

 
 
 

<?php

	include "connection/connection.php";
	  	$aSQL1 = "
		select * from p_profile 
		where c_profile = 'p-010101'
		and nama_form = trim('$script_name')
		";
	    $aQResult1=mysqli_query($conn, $aSQL1);
	
?>

 
<?php
       $no = 0;
	   $nama_form='';
	   $c_profile='';
	   $no=0;
	   while ($aRow1 = mysqli_fetch_array($aQResult1))
	     //while ($aRow = mysqli_fetch_assoc($aQResult1))
       {
	   $no++;
	   $nama_form=$aRow1["nama_form"];
	   $id=$aRow1["id"];
	   echo ">>>   nama_form di p_profile=".$aRow1["nama_form"]."<br>"; //For maintenance
}
?>

	
	<?php  
	   		//echo "<br>".">>>   Current Script_name = "."$script_name"."<br>"; //XXXXXXXXXXXXXopen the left side ("//") for maintain
			$str_hasil = strstr($nama_form, $script_name);
       		echo "<br>"."str_hasil ="."$str_hasil"."<br>"."<br>"; //XXXXopen the left side ("//") for maintain ***********************************************************************************************
		
 			if($str_hasil!=null)
			{
         	//exit();
			print "Profile anda diperbolehkan untuk mengakses ke halaman ini diperbolehkan..."."<br>"."<br>";
			}
			
			elseif($str_hasil==null)
			{
		 	include "login/attention_please.php"; 
         	exit();
			//print "OKe";
			}
	

?>
