<!-- frames -->
<frameset  rows="18%,*" cols="18%,*">
    <frame name="kiri_atas" src="home/kiri_atas.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frame name="tengah_atas" src="home/tengah_atas.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frame name="kiri_bawah" src="home/kb_home.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frame name="tengah_bawah" src="login/login.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
</frameset>
