<!-- frames -->
<frameset  rows="20%,*" cols="16%,*"><!--- kiri_atas ---> <!--- kiri_bawah --->
    <frame name="kiri_atas" src="home/kiri_atas.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frameset  cols="79%,*"><!--- tengah_atas --->
        <frame name="tengah_atas" src="home/tengah_atas.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
        <frame name="kanan_atas" src="home/kanan_atas.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    </frameset>
    <frame name="kiri_bawah" src="home/kiri_bawah.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
    <frameset  cols="79%,*"><!--- tengah_bawah --->
        <frame name="tengah_bawah" src="home/tengah_bawah.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
        <frameset  rows="56%,*"><!--- kanan_tengah --->
            <frame name="kanan_tengah" src="admin/hotnews/messaging.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
            <frame name="kanan_bawah" src="admin/hotnews/messaging_add.php" marginwidth="10" marginheight="10" scrolling="auto" frameborder="0">
        </frameset>
    </frameset>
</frameset>
