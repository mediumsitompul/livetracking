<?php
$script_name=trim($_SERVER["SCRIPT_NAME"]);
//echo "script_name=".$script_name."<br>";
?>
		<table cellspacing="0" cellspading="0" bgcolor="red" width="250" align="center">
          <tr>
            <td class="t1" align="center">
                <font color="#ffffff">Attention please...!!!</font>
                </td>
          </tr>
          <tr>
            <td>
                  <table width="310" bgcolor="yellow">
                    <tr>
                          <td>
                          You don't have authorisation. <br>
						  Please login first... <br>
						  or contact your admin <br>
						  Medium Sitompul<br> 
						  - Medsos=085276203300<br>
						  - Voice=08116091965
						  
			  <!--- Please <a href="../login2.html">Login</a> first...!!!<br> --->
			  
                          </td>
                        </tr>
                  </table>
                </td>
          </tr>
        </table>

