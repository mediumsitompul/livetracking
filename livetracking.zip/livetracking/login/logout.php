<?php
session_start();
session_unset();
//session_unregister('login0');
//session_unregister("password0");
session_destroy();
?>


Logout...

	<script javascript="JavaScript">
        //location.href="../../coc/gangguan_medan_list.php";
	</script>