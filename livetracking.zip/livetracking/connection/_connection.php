<?php
/*
$db_host="localhost";
$db_login="u1654461_rno-one";
$db_password="@RNOSemangat135";
$dbname="u1654461_db_livetracking";
$conn=mysqli_connect($db_host,$db_login,$db_password,$dbname);
//$conn = mysqli_init(); mysqli_options($conn, MYSQLI_OPT_LOCAL_INFILE, true); mysqli_real_connect($conn,$db_host,$db_login,$db_password,$dbname);
*/
?>



<?php

$db_host="localhost:6607";
$db_login="pqr";
$db_password="Pensi2021";
$dbname="db_livetracking";
$conn=mysqli_connect($db_host,$db_login,$db_password,$dbname);
//$conn = mysqli_init(); mysqli_options($conn, MYSQLI_OPT_LOCAL_INFILE, true); mysqli_real_connect($conn,$db_host,$db_login,$db_password,$dbname);

?>