<?php
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
    $aSQL = "Select * from t_hotnews where id= 5";
   	$aQResult = mysqli_query($conn, $aSQL);

       while ($aRow = mysqli_fetch_array($aQResult))
       {
       //echo "<br>";
       $_id = $aRow["id"];
	   $_userid = $aRow["userid"];
       $_subject = $aRow["subject"];
       $_tgl_jam = $aRow["tgl_jam"];
	   $_pictures = $aRow["pictures"];
       //echo "<br>";
       }
       mysqli_free_result($aQResult);
?>





<HTML>
<head>
	<title>Data Module</title>
	<LINK href="../../Style/style2.css" type=text/css rel=STYLESHEET>		
</head>

<BODY bgcolor="aqua">





<form action="user_modify_process.php" method="POST">

   
   <table>

   <tr><td><font face="Arial Black" size="+4" color="black">NAMA PELELANG </font></td> <td> <font face="Arial Black" size="+4" color="blue"> M.SITOMPUL</font></td></tr>
   <tr><td><font face="Arial Black" size="+4" color="black">NOMOR HP </font></td> <td> <font face="Arial Black" size="+4" color="blue"> 085276203300</font></td></tr>


   <tr><td><font face="Arial Black" size="+4" color="black">ITEM LELANG </font></td> <td> <font face="Arial Black" size="+4" color="blue"> SAKSANG</font></td></tr>
   <tr><td><font face="Arial Black" size="+4" color="black">NILAI LELANG </font></td> <td> <font face="Arial Black" size="+4" color="blue"> 250,000</font></td></tr>
   <tr><td><font face="Arial Black" size="+4" color="black">METHODE PEMB </font></td> <td> <font face="Arial Black" size="+4" color="blue"> CASH</font></td></tr>
   
   
   <tr><td><font face="Arial Black" size="+4" color="GRAY">PIC PETUGAS </font></td> <td> <font face="Arial Black" size="+4" color="GRAY"> <?php echo $_userid?></font></td></tr>


   
  
   </font>

   

   
   </table>	



</form>


</BODY>
</HTML>
