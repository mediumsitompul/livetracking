<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>




<?php
/*
	include "../../connection/connection.php";
	$aSQL = "Select * from t_hotnews where id= 5";
	$qry=mysqli_query($conn, $aSQL);
*/
?>
	








<body>
<table width="100%" border="1">
  <tr>
    

	<td>
	<?php 
	include "hotnews_test2.php";
	?>
	</td>






	<td>
	<?php 
	
	include "hotnews_test4.php";
	?>
	</td>
	
	
	
	
	
  </tr>
</table>
</body>
</html>

