<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>




<?php
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	$aSQL = "Select * from t_hotnews where id= 5";
	$qry=mysqli_query($conn, $aSQL);
?>
	


<?php
		$no = 0;
		$userid = "";
       while ($aRow = mysqli_fetch_assoc($qry))
       {
		   $no++;	
		   $userid=$aRow["userid"];
?>



						<tr class="isi">
							<td align="center"><?php echo $no; ?></td>
							<td align="left"><?php echo $aRow["userid"];?></td>
							<td align="left"><?php echo $aRow["subject"];?></td>
							
							<td align="left"><?php echo $aRow["pictures"];?></td>
							
							
					
					        <img src="../../pictures/<?php echo $aRow["pictures"];?>" width="700" height="400" alt="" />
							
							
					
						</tr>
						
						
						
						
						
						
<?php

		}
?>












<body>
<table width="200" border="1">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
