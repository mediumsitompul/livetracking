<?php
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	//$aSQL = "Select * from t_hotnews where id=1";
	$aSQL = "Select * from t_hotnews where id= 5";
	$qry=mysqli_query($conn, $aSQL);
?>
	


<?php
		$no = 0;
		$userid = "";
       while ($aRow = mysqli_fetch_assoc($qry))
       {
		   $no++;	
		   $userid=$aRow["userid"];
?>



						
		<img src="../../pictures/<?php echo $aRow["pictures"];?>" width="600" height="460" alt="" />

								
<?php
}
?>



