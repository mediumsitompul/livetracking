<?php
	session_start();	//Harus pada baris dua, jika tidak akan ada warning, baris satu utk tanda <?
	
	if(isset($_SESSION['login0']) && !empty($_SESSION['login0']))
		//echo "login0=". $_SESSION["login0"]. "<br>";
		$_userid=$_SESSION["login0"];
		
	if(isset($_SESSION['password0']) && !empty($_SESSION['password0']))
		echo "password0=".$_SESSION['password0']."<br>";
	
	if(isset($_SESSION['nama0']) && !empty($_SESSION['nama0']))
		echo "nama0=". $_SESSION['nama0']. "<br>";
		
	if(isset($_SESSION['c_profile0']) && !empty($_SESSION['c_profile0']))
		echo "c_profile0=".$_SESSION['c_profile0']."<br>";
?>


<?php
	//session_start();	//Harus pada baris dua, jika tidak akan ada warning, baris satu utk tanda <?
	//include "../../auth.php";
?>






<?php

//echo "link=".$_GET[link]."<br>";

print "id=".$_GET["id"]."<br>";
$id=$_GET["id"];
$_userid=$_SESSION["login0"];
echo "_userid=".$_userid;
?>




<?php
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL3 = "SELECT *  from t_posisi_gangguan where id = $id ";
    $aQResult3=mysqli_query($conn, $aSQL3);
?>






<?php
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL = "SELECT * from t_posisi_gangguan where id = $id ";
   	$aQResult = mysqli_query($conn, $aSQL);

	   $_id=0;
	   $_witel="";
	   	
       while ($aRow = mysqli_fetch_array($aQResult))
       {
       echo "<br>";
       $_id = $aRow["id"];
	   $_user_id=$aRow["user_id"];
	   $_lat=$aRow["lat"];
	   $_lgt = $aRow["lgt"];
	   $_datetime = $aRow["datetime"];
	   $_remarks = $aRow["remarks"];
       $_remarks2 = $aRow["remarks2"];
	   $_descriptions = $aRow["descriptions"];
	   
	   $_notes = $aRow["remarks"];
       $_flagging_ggn_selesai = $aRow["flagging_ggn_selesai"];
	   $_id_perkiraan = $aRow["id_perkiraan"];
	   
	   
       echo "<br>";
       }
       mysqli_free_result($aQResult);
?>





<HTML>
<head>
	<title>Data Module</title>
	<LINK href="../../Style/style2.css" type=text/css rel=STYLESHEET>		
</head>

<BODY bgcolor="#A8A8FF">

<h2>UPDATE DATA FLAGGING GANGGUAN</h2>
<h2>GANGGUAN TELAH SELESAI DIPERBAIKI</h2>





<form action="gangguan_sebenarnya_modify_process.php" method="POST">
   
   <table>
   <tr><td colspan="2"><hr size="0" noshade></td></tr>
   <tr class="head"><td>ID</td> <td><input type="Text" name="id" readonly="yes" size="20" maxlength="50" value="<?php echo $_id?>"></td></tr>
   <tr class="head"><td>USER_ID</td> <td><input type="Text" name="user_id" size="20" maxlength="20" value="<?php echo $_user_id?>"></td></tr>   
   <tr class="head"><td>LAT</td> <td><input type="Text" name="lat" size="20" maxlength="20" value="<?php echo $_lat?>"></td></tr>
   <tr class="head"><td>LGT</td> <td><input type="Text" name="lgt" size="20" maxlength="20" value="<?php echo $_lgt?>"></td></tr>
   <tr class="head"><td>DATETIME</td> <td><input type="Text" name="datetime" size="20" maxlength="20" value="<?php echo $_datetime?>"></td></tr>
   
   <tr class="head"><td>REMARKS</td> <td><input type="Text" name="remarks" size="20" maxlength="20" value="<?php echo $_remarks?>"></td></tr>
   <tr class="head"><td>REMARKS2</td> <td><input type="Text" name="remarks2" size="20" maxlength="20" value="<?php echo $_remarks2?>"></td></tr>
   <tr class="head"><td>DESCRIPTIONS</td> <td><input type="Text" name="descriptions" size="20" maxlength="20" value="<?php echo $_descriptions?>"></td></tr>
   
   <tr class="head"><td>NOTES</td> <td><input type="Text" name="notes" size="20" maxlength="20" value="<?php echo $_notes?>"></td></tr>
   <tr class="head"><td>FLAGGING_GGN_SELESAI</td> <td><input type="Text" name="flagging_ggn_selesai" size="20" maxlength="20" value="<?php echo $_flagging_ggn_selesai?>"></td></tr>
   <tr class="head"><td>ID_PERKIRAAN</td> <td><input type="Text" name="id_perkiraan" size="20" maxlength="20" value="<?php echo $_id_perkiraan?>"></td></tr>


   
   

   			<tr class="head">
 			<td valign="top" colspan="2">Update Flagging GGN selesai?
    		<input type="radio" name="confirm" value="yes" >Yes
    		<input type="radio" name="confirm" value="no" checked>No
  			</tr>
   
   
   <tr><td colspan="2"><hr size="0" noshade></td></tr>
   </table>	

   <input type="Hidden" name="id" value="<?php echo $_id?>">
   <input type="Hidden" name="link" value="<?php echo $link?>">
   <input type="Hidden" name="_userid" value="<?php echo $_userid?>">
   
   

   <input type="Submit" name="Submit" value="Execute">

</form>


</BODY>
</HTML>
