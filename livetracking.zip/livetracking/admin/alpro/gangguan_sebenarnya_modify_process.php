<?php
	print "confirm=".$_POST["confirm"]."<br>";	
  	print "id=".$_POST["id"]."<br>";
	print "_userid=".$_POST["_userid"]."<br>";
	
?>


<?php

  			if($_POST['confirm']=="yes")
				{
				include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   				//$aSQL = "UPDATE t_posisi_gangguan set flagging_ggn_selesai='1', _user_id='$_POST[_userid]' where id=$_POST[id]";
				$aSQL = "UPDATE t_posisi_gangguan set flagging_ggn_selesai='1', _user_id='$_POST[_userid]', _datetime=now() where id=$_POST[id]";
				
				print $aSQL;
				$aQResult=mysqli_query($conn, $aSQL);
				}
			else
			    {

				}

?>


<script javascript="JavaScript">
location.href="gangguan_sebenarnya_list.php";
</script>


