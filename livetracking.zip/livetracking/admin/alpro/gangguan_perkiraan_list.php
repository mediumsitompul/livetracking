<?php
	//session_start();	//Harus pada baris dua, jika tidak akan ada warning, baris satu utk tanda <?
	//include "../../auth.php";

	//session_start();	//Harus pada baris dua, jika tidak akan ada warning, baris satu utk tanda <?
	//print "login0=". $_SESSION[login0]. "<br>";
	//print "password0=".$_SESSION[password0]."<br>";
	//print "nama0=". $_SESSION[nama0]. "<br>";
	//print "c_profile0=".$_SESSION['c_profile0']."<br>";

	include "../../connection/_connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL = "SELECT * from t_posisi_gangguan";
	$aQResult=mysqli_query($conn, $aSQL);


	$nSQL = "SELECT COUNT(*) as jumlah from t_posisi_gangguan";
	$nQResult = mysqli_query($conn, $nSQL);

	$n = 0;
	
	while($row = mysqli_fetch_assoc($nQResult)){
		$n = $row['jumlah'];
	}

	$script_name=trim($_SERVER["SCRIPT_NAME"]);
	//echo "script_name=".$script_name."<br>";
?>



 
 
<html>
<head>
	<title>Administrasi >> user</title>
	<LINK href="../../Style/style2.css" type=text/css rel=STYLESHEET>		
</head>

<body bgcolor="#D8D8D8">

<center>

<table align="center" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFC68C" height="100%" width="100%">
<tr><td align="center" bgcolor="FFFFFF"  background="../../images/background.jpg" valign="top">



<table border="0" cellpadding="1" cellspacing="1">
	<tr><td colspan="2" align="left" width="200">Gangguan Sebenarnya</a></td><td colspan="2" align="right" width="300">Existing user(s) : <?php echo $n?></td></tr>
</table>	
<br>



<table border="0" cellpadding="1" cellspacing="1" bgColor=#cccccc>
	<tr class="head">
		<td align="center" width="30"><b>ID</b></td>
		<td align="left" width="70"><b>REGIONAL</b></td>
		<td align="left" width="70"><b>WITEL</b></td>
		<td align="left" width="70"><b>UNIT</b></td>
		<td align="left" width="70"><b>USERID</b></td>
		<td align="left" width="120"><b>LAT</b></td>
		<td align="left" width="120"><b>LGT</b></td>
		<td align="left" width="120"><b>DATETIME</b></td>
		<td align="left" width="50"><b>REMARKS</b></td>
		<td align="left" width="80"><b>REMARKS2</b></td>
		<td align="left" width="80"><b>DESCRIPTIONS</b></td>
		<td align="left" width="80"><b>NOTES</b></td>
		<td align="left" width="50"><b>FLAGGING GGN SELESAI</b></td>
		<td align="left" width="50"><b>ID_PERKIRAAN</b></td>
		<td align="left" width="50"><b>DATETIME_GGNCLOSE</b></td>
		<td colspan="1" align="center" width="100px"><b>ACTION</b></td>
	</tr>
	
<?php
		$no = 0;
       while ($aRow = mysqli_fetch_assoc($aQResult))
       {
	   $no++;	
       $id_=$aRow["id"]; //****************** kuncinya ************************
	   
	   
?>
	
	
	<tr class="isi">
		<td align="center"><?php echo $id_;?></td>
		<td align="left"><?php echo $aRow["regional"];?></td>
		<td align="left"><?php echo $aRow["witel"];?></td>
		<td align="left"><?php echo $aRow["unit"];?></td>		
		<td align="left"><?php echo $aRow["user_id"];?></td>
		<td align="left"><?php echo $aRow["lat"];?></td>
		<td align="left"><?php echo $aRow["lgt"];?></td>
		<td align="left"><?php echo $aRow["datetime"];?></td>
		<td align="left"><?php echo $aRow["remarks"];?></td>
		<td align="left"><?php echo $aRow["remarks2"];?></td>
		<td align="left"><?php echo $aRow["descriptions"];?></td>
		<td align="left"><?php echo $aRow["notes"];?></td>	
		<td align="left"><?php echo $aRow["flagging_ggn_selesai"];?></td>	
		<td align="left"><?php echo $aRow["id_perkiraan"];?></td>	
		<td align="left"><?php echo $aRow["_datetime"];?></td>
		
		<td align="center"><a href='gangguan_sebenarnya_modify.php?id=<?php echo $id_;?> '><img src="../../images/edit.gif" border="0"></a></td>
	</tr>
	

<?php
}
?>

</table>

</body>
</html>