
<?php
	include "../../connection/_connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL = "
	
SELECT treg, witel, descriptions, remarks, COUNT(remarks) AS jumlah from t_posisi_alpro_new
GROUP BY treg, witel, remarks, descriptions
	
	
	";
	//$aQResult=mysqli_query($aSQL);
	$aQResult=mysqli_query($conn, $aSQL);
?>




<html>
<head>
	<title>Administrasi >> User</title>
	<LINK href="../../Style/epolice.css" type=text/css rel=STYLESHEET>			
</head>

<body bgcolor="#D8D8D8">

<center>


<table align="center" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFC68C" height="100%" width="100%">
<tr><td align="center" bgcolor="FFFFFF"  background="../../images/background.jpg" valign="top">

<br>
<font color="#800000" size="4" face="Verdana, Arial, Helvetica"><b>Data Route Alpro per Witel</b></font>
<br><br>


<br>

 <?php
 

   if($aQResult)
	{
         $n=mysqli_num_rows($aQResult);
         if($n==0)
		{
		 print "Data yang anda cari tidak ada<br>";
    		}
       else
       {{
	  ?>


<table border="0" cellpadding="1" cellspacing="1" bgColor=#cccccc>

	<tr class="head">
		<td align="center" width="30"><b>NO</b></td>
		<td align="center" width="70"><b>TREG</b></td>
		<td align="left" width="70"><b>WITEL</b></td>
		<td align="left" width="120"><b>ROUTE/REMARK</b></td>
		<td align="center" width="80"><b>DESCRIPTIONS</b></td>		
		<td align="center" width="80"><b>JUMLAH TITIK COORDINAT</b></td>		
				

	</tr>

<?php
	   $no=0;
       while ($aRow = mysqli_fetch_array($aQResult))
       {
	   $no++;	
       $treg_=$aRow["treg"]; //******************** kuncinya ************************
	   $witel_=$aRow["witel"]; //****************** kuncinya ************************
	   $descriptios_=$aRow["descriptions"]; //***** kuncinya ************************
	   $remarks_=$aRow["remarks"]; //************** kuncinya ************************
	   $jumlah_=$aRow["jumlah"]; //**************** kuncinya ************************

?>

	<tr class="isi">
		<td align="center"><?php print $no;?></td>
		<td align="center"><?php print $aRow["treg"];?></td>			
		<td align="left"><?php print $aRow["witel"];?></td>
		<td align="left"><?php print $aRow["remarks"];?></td>
		<td align="left"><?php print $aRow["descriptions"];?></td>
		
		<td align="right"><?php print $aRow["jumlah"];?></td>
		
		
		
	</tr>



<?php
       }
       mysqli_free_result($aQResult);	        
       }}

}

?>

</table>


</body>
</html>
