<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<?php

	$pilih_witel = '';
	//$_GET[pilih_witel];
	
	//$pilih_witel = $_GET[pilih_witel];
	
	//$pilih_datel = $_GET[pilih_datel];

	//echo "pilih_witel = ". $_GET[pilih_witel]."<br>";
	//echo "pilih_datel = ". $_GET[pilih_datel]."<br>";

?>

<?php
	//pilih_tgl_awal
	include "../../../connection/connection.php";
	$aSQL1 = "select distinct(witel) from t_dropcore_result order by witel asc";
	$aQResult1=mysqli_query($conn, $aSQL1);
?>

	

<script>
	function dropdownDatel(witel){
		console.log(witel);
		
		$(document).ready(function(){
			$.get("pilih_datel.php?pilih_witel="+witel, function(data, status){
				console.log(JSON.parse(data).length);
				$('#datel').empty();
				for(i=0;i<=JSON.parse(data).length;i++){
					$('#datel').append($("<option value='"+JSON.parse(data)[i]["datel"]+"'>"+JSON.parse(data)[i]["datel"]+"</option>"));
				}
				
			});
		});
	}
</script>



<!--- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx --->

<?php
  $btn="ENTER";
?>

<script language="JavaScript">


function jump()
{

	var backlink="pilih_witel_datel.php";
	var a=document.inputan.pilih_witel.value;
	var b=document.inputan.pilih_datel.value;
	var k=document.inputan.cmdOk.value;
	
	
	var jumpvalue="?btn="+k+"&pilih_tgl_awal="+a+"&pilih_tgl_akhir="+b; //tidak boleh ada spasi
	
	
	location.href=(backlink+jumpvalue);
}

</script>

<!--- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx --->




<html>
<head>
	<title>Data Module</title>
	<LINK href="../../../Style/style2.css" type=text/css rel=STYLESHEET>		
</head>

<body bgcolor="#ABABD6">



<form action="pilih_witel_datel_process_test.php" method="POST" name="inputan" onsubmit="return validasi()" enctype="multipart/form-data">
<table>	
<font face="Comic Sans MS"size="-1" color="black"><b>PILIH WITEL & DATEL:</b></font>
<tr><td colspan="2"><hr size="0" noshade></td></tr>


	<tr>
	<td class="field"  align="left">Pilih Witel:</td>
	<td>
		<select name="pilih_witel" onChange="dropdownDatel(this.value)">
			<option value=''>Pilih witel</option>
		<?php while ($aRow1 = mysqli_fetch_array($aQResult1)) {?>
			<option value="<?php echo $aRow1['witel'];?>"><?php echo $aRow1['witel'];?></option>
			
		<?php
		}
		?>	
	</select>
	</td>
	</tr>
	

	<tr>
	<td class="field"  align="left">Pilih datel:</td>
	<td>
		<select name="pilih_datel" id="datel">
			<option value='' >Pilih datel</option>
		
	</select>
	</td>
	</tr>		


	
   	<tr>
   	<td>
		
		<input class="tmbl" type="SUBMIT" value="<?php echo $btn?>" name="cmdOk">
		
	</td>
   	</tr>
	
<tr><td colspan="2"><hr size="0" noshade></td></tr>

</table>

</form>



</body>
</html>
