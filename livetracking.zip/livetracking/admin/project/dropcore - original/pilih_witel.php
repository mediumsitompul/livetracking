<?php
	$pilih_witel = "";
	$pilih_datel = "";


	$pilih_witel = $_GET[pilih_witel];
	$pilih_datel = $_GET[pilih_datel];


	//pilih_tgl_awal
	include "../../../connection/connection.php";
	$aSQL1 = "select distinct(witel) from t_dropcore_result order by witel asc";
	$aQResult1=mysqli_query($conn, $aSQL1);
?>

