<?php	
	//pilih_tgl_akhir
	include "../../../connection/connection.php";
	if(isset($_GET['pilih_witel']) && !empty($_GET['pilih_witel'])){
	$aSQL2 = "select distinct(datel) from t_dropcore_result 
	where witel like '$_GET[pilih_witel]' 
	order by datel asc";
	$aQResult2=mysqli_query($conn, $aSQL2);
	
	while( $row = mysqli_fetch_array($aQResult2) ){
      $datel = $row['datel'];

      $datel_array [] = array("datel" => $datel);
   }
	
	echo json_encode($datel_array);
	}
	
?>