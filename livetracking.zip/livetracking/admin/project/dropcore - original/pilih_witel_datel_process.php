<?php
   print "pilih_witel =". $_POST['pilih_witel']."<BR>";
   print "pilih_datel =". $_POST['pilih_datel']."<BR>";
   
   $pilih_witel = $_POST['pilih_witel'];
   $pilih_datel = $_POST['pilih_datel'];
   

   	include "../../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL = "SELECT * from t_dropcore_result where witel='$pilih_witel' and datel='$pilih_datel' ";
	$aQResult=mysqli_query($conn, $aSQL);
	echo $aSQL;
?>


 
 
<html>
<head>
	<title>Administrasi >> user</title>
	<LINK href="../../../Style/style2.css" type=text/css rel=STYLESHEET></LINK>	
</head>

<body bgcolor="#D8D8D8">

<center>

<table align="center" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFC68C" height="100%" width="100%">
<tr><td align="center" bgcolor="FFFFFF"  background="../../images/background.jpg" valign="top">


<br>
<font color="#800000" size="4" face="Verdana, Arial, Helvetica"><b>DATA PANJANG DROP CORE</b></font>

<br>



<table border="0" cellpadding="1" cellspacing="1" bgColor=#cccccc>
	<tr class="head">
		<td align="center" width="30"><b>NO</b></td>
		<td align="center" width="70"><b>WITEL</b></td>
		<td align="left" width="70"><b>DATEL</b></td>
		<td align="left" width="70"><b>SERVICE NUMBER</b></td>
		<td align="left" width="70"><b>CUST_ADDRESS</b></td>
		<td align="left" width="70"><b>LAT_CUSTOMER</b></td>
		<td align="left" width="70"><b>LNG_CUSTOMER</b></td>
		
		<td align="left" width="70"><b>ODP_ADDR_GOOGLE</b></td>
		<td align="left" width="70"><b>ODP_NAME</b></td>
		
		<td align="left" width="70"><b>LATITUDE_ODP</b></td>
		<td align="left" width="70"><b>LONGITUDE_ODP</b></td>
		
		<td align="left" width="70"><b>DISTANCE_RAD</b></td>
		<td align="left" width="70"><b>DISTANCE_ODO</b></td>
>
	</tr>
	
<?php
		$no = 0;
       while ($aRow = mysqli_fetch_assoc($aQResult))
       {
	   $no++;	
	   
	   
?>
	
	
	<tr class="isi">
		<td align="center"><?php echo $no;?></td>
		<td align="left"><?php echo $aRow["witel"];?></td>
		<td align="left"><?php echo $aRow["datel"];?></td>
		<td align="left"><?php echo $aRow["service_number"];?></td>
		<td align="left"><?php echo $aRow["customer_addr"];?></td>
		<td align="left"><?php echo $aRow["latitude_cust"];?></td>
		<td align="left"><?php echo $aRow["longitude_cust"];?></td>
		
		<td align="left"><?php echo $aRow["odp_addr_google"];?></td>
		<td align="left"><?php echo $aRow["odp_name"];?></td>
		
		<td align="left"><?php echo $aRow["latitude_odp"];?></td>
		<td align="left"><?php echo $aRow["longitude_odp"];?></td>
		
		<td align="right"><?php echo $aRow["distance_rad"];?></td>
		<td align="right"><?php echo $aRow["distance_odo"];?></td>

	</tr>
	

<?php
}
?>

</table>

</body>
</html>
