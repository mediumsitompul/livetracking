<?php
   print "pilih_witel =". $_POST['pilih_witel']."<BR>";
   print "pilih_datel =". $_POST['pilih_datel']."<BR>";
   print "pilih_sto =". $_POST['pilih_sto']."<BR>";
   
   $pilih_witel = $_POST['pilih_witel'];
   $pilih_datel = $_POST['pilih_datel'];
   $pilih_sto = $_POST['pilih_sto'];
   

   	//include "../../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	//$aSQL = "SELECT * from t_dropcore_result where witel='$pilih_witel' and datel='$pilih_datel' ";
	//$aQResult=mysqli_query($conn, $aSQL);
	//echo $aSQL;
?>


 