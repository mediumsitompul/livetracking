<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<?php
	include "../../../connection/connection.php";
	$aSQL1 = "select distinct(witel) from t_dropcore_result order by witel asc";
	$aQResult1=mysqli_query($conn, $aSQL1);
?>



<script>


	function dropdownDatel(witel){
		console.log(witel);
		
		$(document).ready(function(){
			$.get("pilih_datel.php?pilih_witel="+witel, function(data, status){
				console.log(JSON.parse(data).length);
				$('#datel').empty();
				for(i=0;i<=JSON.parse(data).length;i++){
					$('#datel').append($("<option value='"+JSON.parse(data)[i]["datel"]+"'>"+JSON.parse(data)[i]["datel"]+"</option>"));
				}
				
			});
		});
	}
	
	
	
	
		function dropdownSto(datel){
		console.log(datel);
		
		$(document).ready(function(){
			$.get("pilih_sto.php?pilih_datel="+datel, function(data, status){
				console.log(JSON.parse(data).length);
				$('#sto').empty();
				for(i=0;i<=JSON.parse(data).length;i++){
					$('#sto').append($("<option value='"+JSON.parse(data)[i]["sto"]+"'>"+JSON.parse(data)[i]["sto"]+"</option>"));
				}
				
			});
		});
	}
	
	
	
	
	
	
</script>



<!--- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx --->

<?php
  $btn="ENTER";
?>






<html>
<head>
	<title>Data Module</title>
	<LINK href="../../../Style/style2.css" type=text/css rel=STYLESHEET>		
</head>

<body bgcolor="#ABABD6">



<form action="pilih_witel_datel_process_test.php" method="POST" name="inputan" onsubmit="return validasi()" enctype="multipart/form-data">
<table>	
<font face="Comic Sans MS"size="-1" color="black"><b>PILIH WITEL & DATEL:</b></font>
<tr><td colspan="2"><hr size="0" noshade></td></tr>


	<tr>
	<td class="field"  align="left">Pilih Witel:</td>
	<td>
		<select name="pilih_witel" onChange="dropdownDatel(this.value)">
			<option value=''>Pilih witel</option>
		<?php while ($aRow1 = mysqli_fetch_array($aQResult1)) {?>
			<option value="<?php echo $aRow1['witel'];?>"><?php echo $aRow1['witel'];?></option>
			
		<?php
		}
		?>	
	</select>
	</td>
	</tr>
	
	
		<tr>
	<td class="field"  align="left">Pilih Datel:</td>
	<td>
		<select name="pilih_datel" id="datel" onChange="dropdownSto(this.value)">
			<option value=''>Pilih datel</option>
	</select>
	</td>
	</tr>
	
	
	
	
	

	<tr>
	<td class="field"  align="left">Pilih sto:</td>
	<td>
		<select name="pilih_sto" id="sto">
			<option value='' >Pilih sto</option>
		
	</select>
	</td>
	</tr>		


	
   	<tr>
   	<td>
		
		<input class="tmbl" type="SUBMIT" value="<?php echo $btn?>" name="cmdOk">
		
	</td>
   	</tr>
	
<tr><td colspan="2"><hr size="0" noshade></td></tr>

</table>

</form>



</body>
</html>
