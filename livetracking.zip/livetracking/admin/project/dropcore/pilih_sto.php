<?php	
	//pilih_tgl_akhir
	include "../../../connection/connection.php";
	if(isset($_GET['pilih_datel']) && !empty($_GET['pilih_datel'])){
	$aSQL2 = "select distinct(sto) from t_dropcore_result 
	where datel like '$_GET[pilih_datel]' 
	order by sto asc";
	
	$aQResult2=mysqli_query($conn, $aSQL2);
	
	while( $row = mysqli_fetch_array($aQResult2) ){
      $sto = $row['sto'];

      $sto_array [] = array("sto" => $sto);
   }
	
	echo json_encode($sto_array);
	}
	
?>