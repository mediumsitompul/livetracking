<?php
	session_start();	//Harus pada baris dua, jika tidak akan ada warning, baris satu utk tanda <?
	//include "../../auth.php";
	//session_start();	//Harus pada baris dua, jika tidak akan ada warning, baris satu utk tanda <?
	//print "login0=". $_SESSION[login0]. "<br>";
	//print "password0=".$_SESSION[password0]."<br>";
	//print "nama0=". $_SESSION[nama0]. "<br>";
	
	//print "c_profile0=".$_SESSION['c_profile0']."<br>";

	include "../../connection/_connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL = "
SELECT t_log_mobile.*, t_user_mobile.nama
FROM t_log_mobile
LEFT JOIN t_user_mobile
ON t_log_mobile.userid=t_user_mobile.userid
order by timestamp asc
	
	";
	$aQResult=mysqli_query($conn, $aSQL);

	
	//$nSQL = "SELECT COUNT(*) as jumlah from t_user_web";
	//$nQResult = mysqli_query($conn, $nSQL);

	//$n = 0;
	//while($row = mysqli_fetch_assoc($nQResult)){
	//	$n = $row["jumlah"];
	//}

//$script_name=trim($_SERVER["SCRIPT_NAME"]);
//echo "script_name=".$script_name."<br>";
?>



 
 
<html>
<head>
	<title>Administrasi >> user</title>
	<LINK href="../../Style/style2.css" type=text/css rel=STYLESHEET></LINK>	
</head>

<body bgcolor="#D8D8D8">

<center>

<table align="center" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFC68C" height="100%" width="100%">
<tr><td align="center" bgcolor="FFFFFF"  background="../../images/background.jpg" valign="top">


<br>
<font color="#800000" size="4" face="Verdana, Arial, Helvetica"><b><a href="mobile_log_list.php">MOBILE LOG LIST</a></b></font>
<br><br>

<br>



<table border="0" cellpadding="1" cellspacing="1" bgColor=#cccccc>
	<tr class="head">
		<td align="center" width="30"><b>NO</b></td>
		<td align="center" width="120"><b>Timestamp</b></td>
		<td align="left" width="80"><b>USERID</b></td>
		<td align="left" width="200"><b>NAMA</b></td>
		<td align="left" width="50"><b>APPS_NAME</b></td>

	</tr>
	
<?php
		$no = 0;
       while ($aRow = mysqli_fetch_assoc($aQResult))
       {
	   $no++;	
       $userid_=$aRow["userid"]; //****************** kuncinya ************************

	   
	   
?>
	
	
	<tr class="isi">
		<td align="center"><?php echo $no;?></td>
		<td align="left"><?php echo $aRow["timestamp"];?></td>
		<td align="left"><?php echo $aRow["userid"];?></td>
		<td align="left"><?php echo $aRow["nama"];?></td>
		<td align="left"><?php echo $aRow["apps_name"];?></td>

	
	</tr>
	

<?php
}
?>

</table>

</body>
</html>
