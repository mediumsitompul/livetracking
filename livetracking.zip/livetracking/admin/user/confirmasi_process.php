

<?php
	print "confirm=".$_POST[confirm]."<br>";	

?>

<?php
  			if($_POST[confirm]=="yes")
				{
				//$password = 'a2ed39c417316adbd5cd1d0211a5d711';
				//include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   				//$aSQL = "UPDATE t_user set nama='$_POST[nama]', c_profile ='$_POST[select_profile]', password ='$password' where userid='$_POST[userid]'";
				//$aQResult=mysql_query($aSQL);
				}
			else
			    {
				//include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   				//$aSQL = "UPDATE t_user set nama='$_POST[nama]', c_profile ='$_POST[select_profile]' where userid='$_POST[userid]'";
				//$aQResult=mysql_query($aSQL);
				}
		
?>





