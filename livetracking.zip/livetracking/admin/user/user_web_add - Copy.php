<?php
//OKE //OKE //OKE //OKE //OKE //OKE 

if (isset($_GET["pilih_treg"]))
{$pilih_treg = $_GET["pilih_treg"];}
else
{$pilih_treg = null;}


if (isset($_GET["pilih_witel"]))
{$pilih_witel = $_GET["pilih_witel"];}
else
{$pilih_witel = null;}


?>		




<?php
	//Pilih_treg
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	$aSQL1 = "select distinct(treg) as treg from p_witel order by treg ";
	//echo $aSQL1;
	$aQResult1=mysqli_query($conn, $aSQL1);
	
	//Pilih_witel
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	$aSQL2 = "select distinct(witel) as witel from p_witel where treg like '$pilih_treg' order by treg, witel";  
	$aQResult2=mysqli_query($conn, $aSQL2);
	

?>

	 
<!--- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx --->



<!--- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx --->

<?php
  $btn="ENTER";
?>

<script language="JavaScript">
function jump()
{
	var backlink="user_web_add.php";
	var a=document.inputan.pilih_treg.value;
	var b=document.inputan.pilih_witel.value;
	var k=document.inputan.cmdOk.value;
	var jumpvalue="?btn="+k+"&pilih_treg="+a+"&pilih_witel="+b;
	location.href=(backlink+jumpvalue);
}
</script>



<!--- xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx --->

<!---  --->

<?php


if($pilih_witel==null and $pilih_treg==null)
   {
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL = "SELECT * from t_p_witel order by treg";
	$aQResult=mysqli_query($conn, $aSQL);
   
   }
 
elseif($pilih_witel==null and $pilih_treg!=null)
   {
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL = "SELECT * from p_witel where treg like '$_GET[pilih_treg]' order by treg";
	$aQResult=mysqli_query($conn, $aSQL);
   
   }
   
   
elseif($pilih_witel!=null and $pilih_treg!=null)
   {
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL = "SELECT * from p_witel where treg like '$_GET[pilih_treg]' and witel like '$_GET[pilih_witel]' order by treg, witel";
	$aQResult=mysqli_query($conn, $aSQL);
   
   }
   
?>
 	   
	   
 
<form action="user_web_add_process.php" method="POST" name="inputan" onsubmit="return validasi()" enctype="multipart/form-data">

<table>	
<tr><td colspan="2"><hr size="0" noshade></td></tr>




	<tr>
	<td class="field" bgcolor="silver" align="left">Pilih Treg:</td>
	<td>
		<select name="pilih_treg" onchange="jump()">
			<option value='' >Pilih_treg</option>
		<?php 
		
		while ($aRow1 = mysqli_fetch_array($aQResult1)) {
		?>\
			<option value="<?php echo $aRow1["treg"]?>"
			<?php if(trim($aRow1["treg"])==$pilih_treg){
			echo 'selected';
			}
			?>
			><?php echo $aRow1["treg"]?></option>
		<?php
		}
		?>	
	</select>
	</td>
	</tr>
	
	<!---  --->
	
	
	<tr>
	<td class="field" bgcolor="silver" align="left">Pilih Witel:</td>
	<td>
		<select name="pilih_witel" onchange="jump()">
			<option value='' >Pilih Witel </option>
		<?php while ($aRow2 = mysqli_fetch_array($aQResult2)) {?>\
			<option value="<?php echo $aRow2["witel"]?>"
			<?php if(trim($aRow2["witel"])==$pilih_witel){
			echo 'selected';
			}
			?>
			><?php echo$aRow2["witel"]?></option>
		<?php
		}
		?>	
	</select>
	</td>
	</tr>	
	
	
	


	
	
	
	
	
   	<tr>
   	<td>
	<input class="tmbl" type="SUBMIT" value="<?php echo $btn?>" name="cmdOk">
	</td>
   	</tr>
	
<tr><td colspan="2"><hr size="0" noshade></td></tr>

</table>

</form>
   
	   


</body>
</html>
