<?php
	print "confirm=".$_POST["confirm"]."<br>";	
	
  	print "idx=".$_POST["idx"]."<br>";
  	print "regional=".$_POST['regional']."<br>";
	print "witel=".$_POST['witel']."<br>";
	print "unit=".$_POST['unit']."<br>";
	print "userid=".$_POST['userid']."<br>";
	print "nama=".$_POST['nama']."<br>";
	print "c_profile=".$_POST['c_profile']."<br>";
	print "flagging=".$_POST['flagging']."<br>";
   	print "select_profile=".$_POST['select_profile']."<br>";    

?>


<?php

  			if($_POST['confirm']=="yes")
				{
				include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   				$aSQL = "UPDATE t_user_mobile_new set flagging='$_POST[flagging]' where idx=$_POST[idx]";
				print $aSQL;
				$aQResult=mysqli_query($conn, $aSQL);
				}
			else
			    {

				}

?>


<script javascript="JavaScript">
location.href="user_mobile_list_validasi.php";
</script>


