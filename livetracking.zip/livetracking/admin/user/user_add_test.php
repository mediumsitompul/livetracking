
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>

<head>
	<title>Administrasi >> User</title>
	<LINK href="../../Style/epolice.css" type=text/css rel=STYLESHEET>			
</head>

<body bgcolor="#D8D8D8">

<center>















<table align="center" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFC68C" height="100%" width="100%">
<tr><td align="center" bgcolor="FFFFFF"  background="../../images/background.jpg" valign="top">

<br>
<font color="#800000" size="4" face="Verdana, Arial, Helvetica"><b>Perhitungan Jarak menurut Jalan</b></font>
<br><br>



<form name="inputan" action="user_add_process.php" method="post">

<table cellpadding="0" cellspacing="0" bgcolor="#c0c0c0">



	
	
<tr>
<td>LATITUDE-1</td><td><input type="text" name="unit" maxlength="30" size="20"></td>
<td>LONGITUDE-1</td><td><input type="text" name="unit" maxlength="30" size="20"></td>
</tr>


	
<tr>
<td>LATITUDE-2</td><td><input type="text" name="unit" maxlength="30" size="20"></td>
<td>LONGITUDE-2</td><td><input type="text" name="unit" maxlength="30" size="20"></td>
</tr>



<tr><td height="5"></td><td></td></tr>
<tr>
<td></td><td><input type="submit" value="SUBMIT"></td>
</tr>
</table>
</form>

</body>
</html>

