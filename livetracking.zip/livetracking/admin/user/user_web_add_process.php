
<?php
$treg =$_POST['pilih_treg'];
$witel =$_POST['pilih_witel'];	
$unit =$_POST['unit'];
$userid =$_POST['userid'];
$nama =$_POST['nama'];
$c_profile =$_POST['c_profile'];
$pass =$_POST['pass'];
$flagging =$_POST['flagging'];

print "treg =".$treg."<BR>";
print "witel =".$witel."<BR>";	
print "nama =".$nama."<BR>";
?>



<?php


	include "../../connection/_connection.php";
	$strSQL = "INSERT INTO t_user_web (regional, witel, unit, userid, nama, c_profile, pass, flagging) 
	VALUES ('$treg',
            '$witel',
			'unit',
            '$userid',
            '$nama',
			'$c_profile',
            md5('$pass'),
            '$flagging' )";
   echo $strSQL;
	$qry = mysqli_query($conn,$strSQL) or die ("Query salah");
?> 
	
	

<script javascript="JavaScript">
        //location.href="user_list.php";
</script>

<?php

include "user_list.php";

?>
	