<?php
$db_host="192.168.100.240:6607";
$db_login="pqr";
$db_password="Pensi2021";
$dbname="db_livetracking";

$conn=mysqli_connect($db_host,$db_login,$db_password,$dbname);
?>

