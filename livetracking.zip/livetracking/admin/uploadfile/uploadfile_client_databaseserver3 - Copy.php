
<?php
   @$loginid = $_POST[loginid];
   @$passwordid =$_POST[passwordid];
   
   echo "loginid = ".$loginid."<br>";
   echo "passwordid = ".$passwordid."<br>";
   
?>





<?php
	include "connection/connection.php";
   	$aSQL = " select * from t_user_web where userid ='$loginid' and pass=md5('$passwordid') ";
	$aQResult=mysqli_query($conn, $aSQL) or die("database error:". mysqli_error($conn));
		
?>





<?php
	   	$no=0;
	   $nama="";
       while ($aRow = mysqli_fetch_assoc($aQResult))
       {
	   	$no++;	
		$nama = $aRow["nama"];
	   }
?>


<?php
    if($nama=="Medium")
	{
?>

<br>

<body bgcolor="#BBFFFF">

<!--- <form enctype="multipart/form-data" action="uploader_a.php" method="POST"> --->

<form enctype="multipart/form-data" action="uploadfile_client_databaseserver4.php" method="POST">

<input type="hidden" name="MAX_FILE_SIZE" value="999999999999999998888888" /> <!--- value="100000000000", total 12 digit OK --->

Browse Data Alpro (csv file) to Upload File: <input name="uploadedfile" type="file" /><br />
<input type="submit" value="Upload File" />
</form>

<?php
	}
	
	if ($nama=="")
	{
	echo "Login/Password anda salah ...";
	}
	
	
?>





	
	
	