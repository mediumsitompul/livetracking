<?php
   echo "DOCUMENT_ROOT=".$_SERVER["DOCUMENT_ROOT"]."<br>";   
?>


Pastikan nama File dibawah ini yang akan anda upload... tidak mengandung spasi...!!!

<br><br>


<?php
//If you want to list only a certain filetype, this case only csv and txt files in an image directory
$dir = opendir ("data1"); 
while (false !== ($file = readdir($dir))) {
if (strpos($file, '.csv',1)||strpos($file, '.txt',1) ) {

//echo "$file <br />";
echo "<a href=uploadfile_client_databaseserver6.php?files=$file>$file</a><br/>"; 
}
}

closedir($dir); 
?>