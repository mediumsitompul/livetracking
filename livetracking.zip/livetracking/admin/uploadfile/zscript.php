<?php
	//print "filename1=".$_POST[filename]."<br>";
	$filename=$_POST[filename];
	//print "filename=".$filename."<br>";
?>



	<?php
	include "../connection/connection.php";
	$strSQL = "insert into t_dapil select * from t_dapil_temporer";
	$qry = mysql_query($strSQL) or die ("Query_1 salah");
	echo "success_1..."."<br>";
	?>
	
	<?php
	include "../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	$strSQL = "truncate t_dapil_temporer";
	$qry = mysql_query($strSQL) or die ("Query_3 salah");
	echo "success_3..."."<br>";
	?>

	<?php
	//File yang akan didelete, harus satu folder dengan scriptnya
	$myFile = "$filename";
	$fh = fopen($myFile, 'w') or die("can't open file");
	fclose($fh);
	
	$myFile = "$filename";
	unlink($myFile);
	//PRINT "was delete...";
	?>

	
	
	<?php
	print "1.Data From ".$filename." sudah di upload ke Database"."<br>";
	print "2.Temporary File ".$filename." sudah di delete"."<br>"."<br>";
	print "Thanks Broo"."<br>";
   ?>

