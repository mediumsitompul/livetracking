
<?php
   echo "DOCUMENT_ROOT=".$_SERVER["DOCUMENT_ROOT"]."<br>";   
?>


<?php
//$target_path = "d:/xampplite/tmp/";
//$target_path = "d:/xampplite/htdocs/uploadfile/data/";
//$target_path = "d:/xampplite/htdocs/swords/ggn/web/admin/pots/uploadfile/data1/";

//$target_path = $_SERVER["DOCUMENT_ROOT"]."/validasi_odp/admin/project/access_servo/uploadfile/data1/";
//$target_path = $_SERVER["DOCUMENT_ROOT"]."/mytools01/admin/uploadfile/data1/";
$target_path = $_SERVER["DOCUMENT_ROOT"]."/livetracking/admin/uploadfile/data1/";



print "target_path =".$target_path."<br>";




$target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 

if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
    echo "The file ".  basename( $_FILES['uploadedfile']['name']). 
    " has been uploaded";
} else{
    echo "There was an error uploading the file, please try again!";
}



?>


<script javascript="JavaScript">
		
		location.href="uploadfile_client_databaseserver5.php";
		
</script>