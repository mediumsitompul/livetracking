<?	
	//print "filename1=".$_POST[filename]."<br>";
	$filename=$_POST[filename];
	//print "filename=".$filename."<br>";
?>






	<?
	
	//File yang akan didelete, harus satu folder dengan scriptnya
	$myFile = "$filename";
	$fh = fopen($myFile, 'w') or die("can't open file");
	fclose($fh);
	
	$myFile = "$filename";
	unlink($myFile);
	//PRINT "was delete...";
	?>

	
	
	<?	
	print "1.Data From ".$filename." sudah di upload ke Database"."<br>";
	print "2.Temporary File ".$filename." sudah di delete"."<br>"."<br>";
	print "Thanks Broo"."<br>";
   ?>

