<?php
	//session_start();	//Harus pada baris dua, jika tidak akan ada warning, baris satu utk tanda <?
	//include "../../../../auth.php";

?>




<!--- <a href="upload_a.php">Upload CSV File Data PSB POTS</a> --->

<a href="uploadfile_client_databaseserver2_login.php">NEXT, Upload File (From Client to Web Server). Line Separator/Delemitter adalah | (pipe)</a>

