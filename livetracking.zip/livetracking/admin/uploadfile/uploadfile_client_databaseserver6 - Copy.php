<?php
	//session_start();	//Harus digabung dlm satu group dengan baris dibawahnya
	//print "login0=". $_SESSION[login0]. "<br>";
?>



<!--- truncate t_odp_ff1 (old data)--->
<?php
/*
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
   	$aSQL0 = "truncate t_user_mobile_temp";
	$aQResult0=mysqli_query($conn, $aSQL0);
	print "Table t_user_mobile_temp was deleted. Finished..."."<br>";
*/
?>



<?php
   echo "DOCUMENT_ROOT=".$_SERVER["DOCUMENT_ROOT"]."<br>";   
   $DOCUMENT_ROOT=$_SERVER["DOCUMENT_ROOT"]."<br>";    
?>

<?php
  echo "files1=".$_GET['files']."<br>"; 
?>




	<?php
	//include "connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	//$strSQL = "DROP TABLE IF EXISTS t_zte_olt_module2_backup";
	//$qry = mysql_query($strSQL) or die ("Query_1 salah");
	//echo "success_1..."."<br>";
	?>



	<?php
	//include "connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	//$strSQL = "CREATE TABLE t_zte_olt_module2_backup SELECT * FROM t_zte_olt_module2_temporer";
	//$qry = mysql_query($strSQL) or die ("Query_2 salah");
	//echo "success_2..."."<br>";
	?>

	<?php
	//$path = "d:/xampplite/htdocs/swords/ggn/web/admin/pots/uploadfile/data1/"; 
	//$path = $_SERVER["DOCUMENT_ROOT"]."/validasi_odp/admin/project/access_servo/uploadfile/data1/"; 
	$path = $_SERVER["DOCUMENT_ROOT"]."/livetracking/admin/uploadfile/data1/"; 
	
	print "path=".$path."<br>"; //ok
	?> 


	<?php
	//include "connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	//$strSQL = "truncate t_zte_olt_module2_temporer";
	//$qry = mysql_query($strSQL) or die ("Query_3 salah");
	//echo "success_3..."."<br>";
	?>

	
	<!--- Upload data to t_odp_ff1 --->
	<?php
	/*
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"   
	//$strSQL1 = "LOAD DATA LOCAL INFILE 'e:/xampp/htdocs/validasi_odp/admin/project/access_servo/uploadfile/data1/$_GET[files]' INTO TABLE t_access_servo_backup FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 1 LINES";
	//$strSQL1 = "LOAD DATA LOCAL INFILE '".$path ."". $_GET['files']."' INTO TABLE t_access_servo_backup FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 3 LINES";
	//  $strSQL1 = "LOAD DATA LOCAL INFILE 'D:/xampp/htdocs/mytools/admin/uploadfile/data1/userid.csv' INTO TABLE t_user_mobile_backup FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 1 LINES";
	$strSQL1 = "LOAD DATA LOCAL INFILE '".$path ."". $_GET['files']."' INTO TABLE t_user_mobile_backup FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 1 LINES";
	echo $strSQL1;
	//echo "<BR>";
	//$qry1 = mysqli_query($conn, $strSQL1) or die ("Error to upload...");
	//$qry1 = mysqli_query($conn, $strSQL1);
	////$qry1=mysqli_query($conn, $strSQL1);
	echo "<BR>"."success_6a..."."<br>"; //ok
	*/
	?>

	<!--- Upload data to t_odp_ff --->
	<?php

	
	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"   
	  //$strSQL = "LOAD DATA LOCAL INFILE 'd:/xampp/htdocs/oltnms/admin/scripts/uploadfile6/data1/$_GET[files]' INTO TABLE t_psbpots FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 1 LINES";
	  $strSQL2a = "LOAD DATA LOCAL INFILE '".$path ."". $_GET['files']."' INTO TABLE t_posisi_alpro_new_upload FIELDS TERMINATED BY '|' IGNORE 1 LINES ";
	  
	  //$strSQL2 = "LOAD DATA LOCAL INFILE '".$path ."". $_GET['files']."' INTO TABLE t_posisi_alpro_new_upload FIELDS TERMINATED BY '|' IGNORE 1 LINES";
	  //$strSQL2 = "LOAD DATA LOCAL INFILE 'D:/xampp/htdocs/mytools/admin/uploadfile/data1/alpro_csv.csv' INTO TABLE t_alpro_from_upload FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 1 LINES";
	  print $strSQL2a;
	
	//$qry2 = mysqli_query($conn, $strSQL2a) or die ("Error to upload...!!!");
	
	$qry2 = mysqli_query($conn, $strSQL2a);
	

	echo "<BR>"."success_6b..."."<br>"; //ok
	
	?>
	
	
	<?php 
	//include "connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	//$strSQL = "update t_service_status_ftp set userid_enter='$_SESSION[login0]', datetime_enter=NOW() 
    //where ((datetime_enter='0000-00-00 00:00:00') or (datetime_enter is null) or (userid_enter is null))";
	//qry = mysql_query($strSQL) or die ("Query_5 salah");
	//echo "success_5..."."<br>";
	?>
	
	
	
	<?php
	//include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	//$strSQL = "update t_zte_olt_module set userid_enter='$_SESSION[login0]', datetime_enter=NOW() ";
	//$qry = mysql_query($strSQL) or die ("Query_5 salah");
	//echo "success_5..."."<br>";
	?>
	

<?php 
//unlink("data1/".$_GET['files']);
?>
