
<?php
  $c_profile=$_POST['c_profile'];	
  $l_profile=$_POST['l_profile'];	
  $d_profile=$_POST['d_profile'];	
  $nama_form=$_POST['nama_form'];	
?>



<?php

	include "../../connection/connection.php";  // untuk fungsi: "$db_host", "$db_login", "$db_password"
	$strSQL = "INSERT INTO p_profile (c_profile, l_profile, d_profile, nama_form) VALUES ('$c_profile', '$l_profile', '$d_profile', '$nama_form' )";
	$qry = mysqli_query($conn, $strSQL) or die ("Query salah");
		
?>



<?php
include "profile_list.php";
?>



