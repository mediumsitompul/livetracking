
//Define calendar(s): addCalendar ("Unique Calendar Name", "Window title", "Form element's name", Form name")
addCalendar("Calendar1", "Select Date", "tgl_input1", "inputan");
addCalendar("Calendar2", "Select Date", "tgl_input2", "inputan");
addCalendar("Calendar3", "Select Date", "tgl_input3", "inputan");
addCalendar("Calendar4", "Select Date", "tgl_input4", "inputan");
addCalendar("Calendar5", "Select Date", "tgl_input5", "inputan");


 setWidth(90, 1, 15, 1);
