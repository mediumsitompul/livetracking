
//Define calendar(s): addCalendar ("Unique Calendar Name", "Window title", "Form element's name", Form name")
addCalendar("Calendar1", "Select Date", "date_start", "inputan");
addCalendar("Calendar2", "Select Date", "date_end", "formAction");

//untuk script report resume hadir
addCalendar("Calendar3", "Select Date", "tgl1", "formAction");
addCalendar("Calendar4", "Select Date", "tgl2", "formAction");

//untuk script /jwr/oph/upload_gamas.php
addCalendar("Calendar5", "Select Date", "tgl_gamas", "inputan");
addCalendar("Calendar6", "Select Date", "tgl_awal", "inputan");
addCalendar("Calendar7", "Select Date", "tgl_akhir", "inputan");
addCalendar("Calendar8", "Select Date", "tgl2", "formAction");

 setWidth(90, 1, 15, 1);
